
import React from 'react';
import ThreeScene from './ThreeScene.tsx';

const Hero: React.FC = () => {
  return (
    <div className="relative h-[100svh] w-full flex items-center justify-center overflow-hidden bg-black">
      {/* Immersive 3D Background */}
      <div className="absolute inset-0 z-0">
        <ThreeScene />
      </div>

      {/* Depth Overlays */}
      <div className="absolute inset-0 z-[1] pointer-events-none bg-gradient-to-b from-black/80 via-transparent to-black"></div>
      
      {/* Content Layer */}
      <div className="relative z-10 text-center px-6 max-w-6xl mt-[-5svh]">
        <div className="inline-flex items-center gap-3 px-6 py-2 mb-10 border border-sky-400/30 bg-black/40 text-sky-400 text-[10px] font-black uppercase tracking-[0.6em] animate-float blue-aura backdrop-blur-xl rounded-full">
          <span className="w-2 h-2 bg-sky-400 rounded-full animate-pulse shadow-[0_0_10px_#0ea5e9]"></span>
          NOVA Quantum Interface
        </div>
        
        <h1 className="text-7xl sm:text-8xl md:text-[10rem] font-black mb-6 tracking-tighter leading-[0.75] text-white select-none drop-shadow-2xl">
          THE <br />
          <span className="text-gradient-blue blue-glow-text">SINGULARITY</span>
        </h1>
        
        <p className="text-[10px] md:text-xs text-zinc-400 font-mono mb-16 max-w-xl mx-auto uppercase tracking-[0.5em] leading-[2.5] opacity-70">
          Decentralized Intelligence. Immersive Architecture. <br />
          Engineered by Syed Shayan Ali for the 2050 Paradigm.
        </p>
        
        <div className="flex flex-col sm:flex-row items-center justify-center gap-8">
          <a 
            href="#ai" 
            className="group relative w-full sm:w-auto px-16 py-5 bg-sky-500 text-black font-black text-xs uppercase transition-all tracking-[0.2em] overflow-hidden"
          >
            <span className="relative z-10">Access Strategist</span>
            <div className="absolute inset-0 bg-white translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
          </a>
          <button className="w-full sm:w-auto px-16 py-5 border border-sky-500/20 text-white font-black text-xs uppercase hover:bg-sky-500/10 hover:border-sky-400/50 transition-all tracking-[0.2em] backdrop-blur-sm">
            Neural Nodes
          </button>
        </div>
      </div>

      {/* Decorative corner elements */}
      <div className="absolute bottom-16 left-16 hidden xl:block opacity-20 select-none">
        <div className="text-[9px] text-sky-400 font-mono font-black space-y-2 uppercase tracking-[0.4em]">
          <div>LOC_LAT: 24.8607° N</div>
          <div>LOC_LONG: 67.0011° E</div>
          <div className="text-white">STATUS: CORE_STABLE</div>
        </div>
      </div>

      <div className="absolute top-16 right-16 hidden lg:block opacity-20 select-none">
        <div className="text-[9px] text-zinc-500 font-mono text-right space-y-2 uppercase tracking-[0.4em]">
          <div>ARCHITECT: SYED SHAYAN ALI</div>
          <div className="text-sky-400">AGENCY: NOVA INTERNATIONAL</div>
        </div>
      </div>
      
      {/* Scroll indicator with refined design */}
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 opacity-30 group cursor-pointer">
        <div className="flex flex-col items-center gap-4">
          <span className="text-[8px] font-black tracking-[0.8em] uppercase text-zinc-500 group-hover:text-sky-400 transition-colors">Initiate Sequence</span>
          <div className="w-px h-16 bg-gradient-to-b from-sky-400 to-transparent"></div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
