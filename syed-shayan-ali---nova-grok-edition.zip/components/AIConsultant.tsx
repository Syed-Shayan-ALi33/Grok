
import React, { useState, useRef, useEffect } from 'react';
import { getAIResponse } from '../services/ai.ts';

interface Message {
  role: 'user' | 'ai';
  text: string;
}

const AIConsultant: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userPrompt = input.trim();
    setInput('');
    
    setMessages(prev => [...prev, { role: 'user', text: userPrompt }]);
    setIsLoading(true);

    const aiResponse = await getAIResponse(userPrompt);
    
    setMessages(prev => [...prev, { role: 'ai', text: aiResponse }]);
    setIsLoading(false);
  };

  return (
    <div className="w-full max-w-4xl mx-auto glass-panel rounded-xl overflow-hidden flex flex-col h-[650px] shadow-[0_0_80px_rgba(14,165,233,0.1)] border-white/10">
      {/* Consultant Header */}
      <div className="px-6 py-5 border-b border-sky-500/20 flex items-center justify-between bg-black/40">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 flex items-center justify-center border border-sky-400 bg-sky-500/10 text-sky-400 font-black text-xl shadow-[0_0_15px_rgba(14,165,233,0.3)]">
            N
          </div>
          <div>
            <h3 className="font-bold text-white text-base tracking-widest uppercase blue-glow-text">NOVA Strategist</h3>
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 bg-sky-400 rounded-full animate-pulse shadow-[0_0_8px_#0ea5e9]"></span>
              <span className="text-[10px] text-sky-500 font-bold uppercase tracking-widest">Syed Shayan Ali AI // ACTIVE</span>
            </div>
          </div>
        </div>
        <div className="hidden sm:block text-[10px] text-zinc-500 font-mono tracking-tighter opacity-50">
          CORE_ENGINE: GEMINI-3-FLASH
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-8 bg-black/20">
        {messages.length === 0 && !isLoading && (
          <div className="h-full flex flex-col items-center justify-center text-zinc-600 text-center font-mono p-12">
            <div className="w-px h-12 bg-sky-500/30 mb-6"></div>
            <p className="text-[11px] uppercase tracking-[0.5em] mb-4 text-sky-500/80">Awaiting Input</p>
            <p className="text-[12px] max-w-xs leading-relaxed">NOVA Grok is ready to architect your digital future. Powered by Gemini, ask anything.</p>
          </div>
        )}
        
        {messages.map((msg, index) => (
          <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`relative max-w-[85%] px-6 py-4 rounded-sm border transition-all ${
              msg.role === 'user' 
                ? 'bg-zinc-900/50 border-zinc-700 text-white' 
                : 'bg-black/80 border-sky-500/30 text-zinc-100 font-mono text-[13px] shadow-[0_0_30px_rgba(14,165,233,0.05)]'
            }`}>
              {msg.role === 'ai' && (
                <div className="text-[9px] text-sky-500 mb-3 uppercase tracking-[0.3em] font-sans font-black opacity-80">NOVA Response</div>
              )}
              <p className="leading-relaxed whitespace-pre-wrap">{msg.text}</p>
            </div>
          </div>
        ))}
        
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-black/50 border border-sky-500/20 px-6 py-4 rounded-sm">
              <div className="flex gap-2">
                <div className="w-1.5 h-1.5 bg-sky-400 rounded-full animate-bounce"></div>
                <div className="w-1.5 h-1.5 bg-sky-400 rounded-full animate-bounce [animation-delay:0.1s]"></div>
                <div className="w-1.5 h-1.5 bg-sky-400 rounded-full animate-bounce [animation-delay:0.2s]"></div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Input */}
      <div className="p-6 border-t border-sky-500/20 bg-black/60">
        <form onSubmit={handleSubmit} className="relative">
          <input 
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Transmit command..."
            className="w-full bg-black/40 border border-white/10 rounded-sm pl-5 pr-20 py-4 text-white font-mono text-sm focus:outline-none focus:border-sky-500/50 transition-all placeholder:text-zinc-700"
          />
          <button 
            type="submit"
            disabled={isLoading || !input.trim()}
            className="absolute right-2 top-1/2 -translate-y-1/2 bg-sky-500 text-black px-6 py-2 rounded-sm font-black text-[11px] uppercase hover:bg-white transition-all disabled:bg-zinc-800 disabled:text-zinc-600 shadow-[0_0_15px_rgba(14,165,233,0.2)]"
          >
            {isLoading ? '...' : 'Send'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default AIConsultant;
