
import React, { useState, useEffect } from 'react';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'py-4 bg-black border-b border-white/10' : 'py-8 bg-transparent'}`}>
      <div className="max-w-7xl mx-auto px-8 flex justify-between items-center">
        <div className="flex items-center gap-4">
          <div className="w-6 h-6 border-2 border-white flex items-center justify-center font-bold text-sm text-white">M</div>
          <span className="text-lg font-bold tracking-tighter text-white uppercase">
            Syed Shayan Ali
          </span>
        </div>

        <div className="hidden md:flex items-center gap-12">
          {['Home', 'AI', 'Contact'].map((item) => (
            <a key={item} href={`#${item.toLowerCase()}`} className="text-zinc-500 hover:text-white transition-colors text-[10px] font-bold uppercase tracking-[0.2em]">
              {item}
            </a>
          ))}
          <a 
            href="https://www.linkedin.com/in/syed-shayan-ali-12b069373" 
            target="_blank" 
            className="px-4 py-1.5 border border-white text-white text-[10px] font-bold uppercase hover:bg-white hover:text-black transition-all"
          >
            LinkedIn
          </a>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
