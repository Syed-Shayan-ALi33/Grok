
import React from 'react';

const LoadingScreen: React.FC = () => {
  return (
    <div className="fixed inset-0 bg-slate-950 flex flex-col items-center justify-center z-[100]">
      <div className="relative w-24 h-24 mb-8">
        <div className="absolute inset-0 border-4 border-cyan-500/20 rounded-full"></div>
        <div className="absolute inset-0 border-4 border-cyan-500 rounded-full border-t-transparent animate-spin"></div>
        <div className="absolute inset-4 border-4 border-indigo-500 rounded-full border-b-transparent animate-spin-slow"></div>
      </div>
      <h2 className="text-xl md:text-2xl font-bold tracking-[0.4em] text-white">SYED SHAYAN <span className="text-cyan-400">ALI</span></h2>
      <p className="mt-4 text-slate-500 text-[10px] uppercase tracking-widest animate-pulse">NOVA International Engaged...</p>
      
      <style>{`
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(-360deg); }
        }
        .animate-spin-slow {
          animation: spin-slow 2s linear infinite;
        }
      `}</style>
    </div>
  );
};

export default LoadingScreen;
