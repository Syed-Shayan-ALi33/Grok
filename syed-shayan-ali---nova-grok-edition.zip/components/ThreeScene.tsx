import React, { useRef, useMemo, Suspense } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { 
  Float, 
  MeshDistortMaterial, 
  Sphere, 
  Points,
  PointMaterial,
  PresentationControls,
  Environment
} from '@react-three/drei';
import * as THREE from 'three';

// A reactive light that follows the mouse to create dynamic shadows and highlights
const DynamicLight = () => {
  const lightRef = useRef<THREE.PointLight>(null!);
  useFrame((state) => {
    const { x, y } = state.mouse;
    if (lightRef.current) {
      lightRef.current.position.set(x * 12, y * 12, 5);
    }
  });
  return <pointLight ref={lightRef} intensity={8} color="#0ea5e9" distance={25} />;
};

// The "Digital Ocean" - a flowing plane at the bottom that looks like data waves
const DigitalOcean = () => {
  const meshRef = useRef<THREE.Mesh>(null!);
  
  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    if (meshRef.current) {
      meshRef.current.position.y = -6 + Math.sin(time * 0.5) * 0.5;
    }
  });

  return (
    <mesh ref={meshRef} rotation={[-Math.PI / 2, 0, 0]} position={[0, -6, 0]}>
      <planeGeometry args={[100, 100, 60, 60]} />
      <MeshDistortMaterial
        color="#020617"
        speed={1.5}
        distort={0.4}
        radius={1}
        wireframe
        emissive="#0ea5e9"
        emissiveIntensity={0.2}
        transparent
        opacity={0.3}
      />
    </mesh>
  );
};

// The "Quantum Core" - the central focus of NOVA
const QuantumCore = () => {
  const coreRef = useRef<THREE.Group>(null!);
  const shellRef = useRef<THREE.Mesh>(null!);
  const innerRef = useRef<THREE.Mesh>(null!);

  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    if (coreRef.current) {
      coreRef.current.rotation.y = time * 0.2;
      coreRef.current.rotation.x = Math.sin(time * 0.1) * 0.1;
      
      const mouseDist = Math.sqrt(state.mouse.x ** 2 + state.mouse.y ** 2);
      const scale = 1 + (1 - Math.min(mouseDist, 1)) * 0.2;
      coreRef.current.scale.setScalar(THREE.MathUtils.lerp(coreRef.current.scale.x, scale, 0.1));
    }
    if (shellRef.current) {
      shellRef.current.rotation.z = time * 0.5;
    }
    if (innerRef.current) {
      innerRef.current.rotation.y = -time * 0.8;
    }
  });

  return (
    <group ref={coreRef}>
      <Sphere args={[1, 64, 64]}>
        <MeshDistortMaterial
          color="#ffffff"
          speed={3}
          distort={0.5}
          radius={1}
          emissive="#0ea5e9"
          emissiveIntensity={2}
          roughness={0}
          metalness={1}
        />
      </Sphere>

      <mesh ref={shellRef}>
        <octahedronGeometry args={[2.2, 0]} />
        <meshStandardMaterial 
          color="#0ea5e9" 
          wireframe 
          transparent 
          opacity={0.3} 
          emissive="#0ea5e9"
          emissiveIntensity={1.5}
        />
      </mesh>

      <mesh ref={innerRef}>
        <torusKnotGeometry args={[1.5, 0.02, 128, 16]} />
        <meshStandardMaterial 
          color="#ffffff" 
          emissive="#0ea5e9" 
          emissiveIntensity={5}
        />
      </mesh>

      <Sphere args={[2.5, 32, 32]}>
        <meshStandardMaterial 
          color="#0ea5e9" 
          transparent 
          opacity={0.05} 
          blending={THREE.AdditiveBlending}
          depthWrite={false}
        />
      </Sphere>
    </group>
  );
};

const ParticleVortex = () => {
  const count = 6000;
  const positions = useMemo(() => {
    const p = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const radius = 5 + Math.random() * 20;
      const angle = Math.random() * Math.PI * 2;
      p[i * 3] = Math.cos(angle) * radius;
      p[i * 3 + 1] = (Math.random() - 0.5) * 30;
      p[i * 3 + 2] = Math.sin(angle) * radius;
    }
    return p;
  }, []);

  const pointsRef = useRef<THREE.Points>(null!);

  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    if (pointsRef.current) {
      pointsRef.current.rotation.y = time * 0.05;
      pointsRef.current.position.y = Math.sin(time * 0.2) * 2;
    }
  });

  return (
    <Points ref={pointsRef} positions={positions} stride={3}>
      <PointMaterial
        transparent
        color="#0ea5e9"
        size={0.05}
        sizeAttenuation={true}
        depthWrite={false}
        opacity={0.4}
        blending={THREE.AdditiveBlending}
      />
    </Points>
  );
};

const ThreeScene: React.FC = () => {
  return (
    <div className="w-full h-full">
      <Canvas
        camera={{ position: [0, 0, 15], fov: 45 }}
        dpr={[1, 2]}
        gl={{ antialias: true, alpha: true }}
      >
        <color attach="background" args={['#000000']} />
        
        <Suspense fallback={null}>
          <ambientLight intensity={0.2} />
          <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={2} color="#ffffff" />
          <DynamicLight />
          
          {/* Fix: removed non-existent 'config' prop and passed spring configuration directly to 'snap' as per PresentationControls documentation */}
          <PresentationControls
            global
            snap={{ mass: 2, tension: 500 }}
            rotation={[0, 0, 0]}
            polar={[-Math.PI / 10, Math.PI / 10]}
            azimuth={[-Math.PI / 10, Math.PI / 10]}
          >
            <QuantumCore />
          </PresentationControls>

          <DigitalOcean />
          <ParticleVortex />
          
          <fog attach="fog" args={['#000000', 10, 30]} />
          <Environment preset="night" />
        </Suspense>
      </Canvas>
    </div>
  );
};

export default ThreeScene;