
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="relative z-10 border-t border-white/10 py-20 bg-black">
      <div className="max-w-7xl mx-auto px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 mb-20">
          <div className="lg:col-span-2">
            <h2 className="text-2xl font-bold text-white mb-6 uppercase tracking-tighter">NOVA International</h2>
            <p className="text-zinc-500 max-w-md font-mono text-sm leading-relaxed">
              Syed Shayan Ali's digital architecture firm. We build what others fear to imagine.
            </p>
          </div>
          <div>
            <h4 className="text-[10px] text-zinc-400 font-bold uppercase tracking-[0.3em] mb-8">Communications</h4>
            <div className="space-y-4 font-mono text-xs text-white">
              <p className="hover:line-through cursor-pointer transition-all">shayasyedali87@gmail.com</p>
              <p>03145436278</p>
            </div>
          </div>
          <div>
            <h4 className="text-[10px] text-zinc-400 font-bold uppercase tracking-[0.3em] mb-8">Access</h4>
            <div className="flex gap-4">
              <a href="https://www.linkedin.com/in/syed-shayan-ali-12b069373" target="_blank" className="w-10 h-10 border border-white/20 flex items-center justify-center text-white hover:bg-white hover:text-black transition-all">
                IN
              </a>
            </div>
          </div>
        </div>
        <div className="flex flex-col md:flex-row justify-between items-center border-t border-white/5 pt-10 text-[9px] font-mono text-zinc-600 uppercase tracking-widest">
          <p>© 2024 NOVA International. Under Management of Syed Shayan Ali.</p>
          <p className="mt-4 md:mt-0">Karachi // Worldwide</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
