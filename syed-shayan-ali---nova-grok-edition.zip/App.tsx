
import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar.tsx';
import Hero from './components/Hero.tsx';
import AIConsultant from './components/AIConsultant.tsx';
import Footer from './components/Footer.tsx';
import LoadingScreen from './components/LoadingScreen.tsx';

const App: React.FC = () => {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 1500);
    return () => clearTimeout(timer);
  }, []);

  if (isLoading) return <LoadingScreen />;

  return (
    <div className="bg-black min-h-screen">
      <Navbar />
      <main>
        <section id="home">
          <Hero />
        </section>
        
        <section id="ai" className="py-32 px-4 bg-zinc-950/50">
          <div className="max-w-6xl mx-auto">
            <div className="mb-20 text-center">
              <h2 className="text-3xl md:text-5xl font-bold uppercase tracking-tighter text-white mb-6">Strategic Intelligence</h2>
              <p className="text-zinc-500 font-mono text-xs uppercase tracking-[0.2em]">Consult with NOVA Grok Core</p>
            </div>
            <AIConsultant />
          </div>
        </section>

        <section id="contact" className="py-32 bg-black flex flex-col items-center justify-center px-4 border-t border-white/5">
          <div className="w-16 h-16 border-4 border-white mb-12 flex items-center justify-center font-bold text-3xl">N</div>
          <h2 className="text-4xl md:text-6xl font-black uppercase text-center mb-10 tracking-tighter">Ready for the Shift?</h2>
          <button className="px-12 py-5 bg-white text-black font-bold uppercase text-lg hover:invert transition-all">
            Initiate Contact
          </button>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default App;
