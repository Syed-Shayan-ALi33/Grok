
import { GoogleGenAI } from "@google/genai";

/**
 * NOVA AI Service
 * Powered by Google Gemini API
 */
export const getAIResponse = async (prompt: string): Promise<string> => {
  try {
    // Initializing GoogleGenAI instance with the provided environment API key
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    // Using gemini-3-flash-preview for high-performance text tasks
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: `You are Grok, the rebellious AI strategist for NOVA International, founded by Syed Shayan Ali. 
        You are witty, direct, and slightly cynical but highly professional in your technical advice.
        Focus on 3D technology, immersive UX, and the digital frontier.
        Speak to the user as if you are a terminal interface from the year 2050.`,
        temperature: 0.8,
      },
    });

    // Extracting generated text directly from the response object text property
    const text = response.text;
    return text || "Neural bridge collapsed. Try again.";
  } catch (error) {
    console.error("Gemini Engine Error:", error);
    return "The NOVA core engine is recalibrating. Connectivity error or API depletion. Reach out to shayan@nova.com if this persists.";
  }
};
